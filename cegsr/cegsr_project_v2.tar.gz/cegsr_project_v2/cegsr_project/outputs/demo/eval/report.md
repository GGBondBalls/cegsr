# Run Summary

## Aggregate Metrics
- **num_episodes**: 20
- **accuracy**: 0.85
- **exact_match**: 0.75
- **mcq_accuracy**: 0.85
- **repair_coverage**: 0.0
- **repair_success_rate**: 0.0
- **num_changed_repairs**: 0
- **average_trajectory_length**: 4.0
- **average_input_tokens**: 1299.85
- **average_output_tokens**: 232.85
- **retrieval_hit_usefulness_proxy**: 0.0
- **graph_num_nodes**: 74
- **graph_num_edges**: 280
- **training_data_size_by_role::planner**: 20
- **training_data_size_by_role::solver**: 20
- **training_data_size_by_role::verifier**: 20
- **training_data_size_by_role::summarizer**: 20
- **dataset_accuracy::commonsense_qa**: 0.85
- **dataset_count::commonsense_qa**: 20
- **category_accuracy::commonsense**: 0.85

## Dataset Breakdown
- commonsense_qa: 0.85

## Error Cases
- sample_id=commonsenseqa_validation_0 | dataset=commonsense_qa | pred=E. hall | gold=D. living room
- sample_id=commonsenseqa_validation_5 | dataset=commonsense_qa | pred=C. kitchen cupboard | gold=B. table setting
- sample_id=commonsenseqa_validation_11 | dataset=commonsense_qa | pred=A. ocean | gold=C. water
