#!/usr/bin/env bash
set -euo pipefail

llamafactory-cli train outputs\demo\training_data\llamafactory_planner_lora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_planner_qlora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_solver_lora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_solver_qlora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_verifier_lora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_verifier_qlora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_summarizer_lora.yaml
llamafactory-cli train outputs\demo\training_data\llamafactory_summarizer_qlora.yaml
