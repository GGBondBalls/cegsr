from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any

from cegsr.experience.graph_store import GraphStore
from cegsr.trajectories.schema import AgentTurn, ExperienceNode


class LocalEmbedder:
    """
    Graceful local embedding layer.
    - preferred: sentence-transformers
    - fallback: hashed bag-of-words
    """

    def __init__(self, model_name_or_path: str | None = None, dim: int = 128) -> None:
        self.model_name_or_path = model_name_or_path
        self.dim = dim
        self._model = None
        if model_name_or_path:
            try:
                from sentence_transformers import SentenceTransformer  # type: ignore

                self._model = SentenceTransformer(model_name_or_path)
            except Exception:
                self._model = None

    def encode(self, text: str) -> list[float]:
        if self._model is not None:
            vector = self._model.encode([text], normalize_embeddings=True)[0]
            return [float(x) for x in vector]
        tokens = re.findall(r"\w+", text.lower())
        counter = Counter(tokens)
        vector = [0.0] * self.dim
        for token, count in counter.items():
            idx = hash(token) % self.dim
            vector[idx] += float(count)
        norm = math.sqrt(sum(v * v for v in vector)) or 1.0
        return [v / norm for v in vector]


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b:
        return 0.0
    size = min(len(a), len(b))
    return sum(a[i] * b[i] for i in range(size))


class ExperienceRetriever:
    def __init__(self, graph_store: GraphStore, embedder: LocalEmbedder) -> None:
        self.graph_store = graph_store
        self.embedder = embedder

    def retrieve(
        self,
        role: str,
        task_type: str,
        query: str,
        history: list[AgentTurn],
        top_k: int = 3,
        expand_neighbors: bool = True,
    ) -> list[ExperienceNode]:
        query_text = f"role={role}\ntask={task_type}\nquestion={query}\nhistory={' '.join(t.response for t in history[-2:])}"
        q = self.embedder.encode(query_text)
        candidates = []
        for node in self.graph_store.nodes.values():
            if node.task_type != task_type:
                continue
            if node.role not in {role, "summarizer", "solver"}:
                continue
            if not node.embedding:
                node.embedding = self.embedder.encode(node.text)
            score = cosine(q, node.embedding) + 0.1 * float(node.credit)
            candidates.append((score, node))
        top = [node for _, node in sorted(candidates, key=lambda x: x[0], reverse=True)[:top_k]]
        if not expand_neighbors:
            return top
        expanded: dict[str, ExperienceNode] = {n.node_id: n for n in top}
        for node in top:
            for neighbor in self.graph_store.neighbors(node.node_id):
                expanded.setdefault(neighbor.node_id, neighbor)
        return list(expanded.values())[: max(top_k, len(top))]
