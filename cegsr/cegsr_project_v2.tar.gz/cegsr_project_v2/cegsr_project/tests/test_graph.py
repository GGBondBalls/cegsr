from tempfile import TemporaryDirectory

from cegsr.credit.outcome_credit import OutcomeCreditSignal
from cegsr.credit.verifier_credit import VerifierCreditSignal
from cegsr.credit.dependency_credit import DependencyCreditSignal
from cegsr.credit.fusion import fuse_credit_records
from cegsr.experience.builder import build_experience_graph_from_episodes
from cegsr.experience.graph_store import GraphStore
from cegsr.trajectories.schema import EpisodeTrajectory, TaskSample, AgentTurn
from cegsr.trajectories.segmentation import segment_episode


def test_graph_build():
    ep = EpisodeTrajectory(
        episode_id="ep1",
        sample=TaskSample(sample_id="s1", question="2+2?", answer="4"),
        turns=[
            AgentTurn(turn_id="t1", role="planner", prompt_messages=[], response="plan"),
            AgentTurn(turn_id="t2", role="solver", prompt_messages=[], response="Proposed answer: 4", dependencies=["t1"]),
            AgentTurn(turn_id="t3", role="summarizer", prompt_messages=[], response="Final Answer: 4", dependencies=["t1","t2"]),
        ],
        metrics={"accuracy": 1, "exact_match": 1},
    )
    segment_episode(ep)
    groups = [OutcomeCreditSignal().compute(ep), VerifierCreditSignal().compute(ep), DependencyCreditSignal().compute(ep)]
    fuse_credit_records(ep, groups)
    with TemporaryDirectory() as tmp:
        store = build_experience_graph_from_episodes([ep], tmp, min_credit=0.1)
        loaded = GraphStore.load(tmp)
        assert store.stats()["num_nodes"] >= 1
        assert loaded.stats()["num_edges"] >= 1
